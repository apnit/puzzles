package string_encryption;

public class Encryption {
    public static String Encrypt(String str) {

        StringBuilder string = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            if (i < (length - 1)) {
                int a = str.charAt(i);
                int b = str.charAt(i + 1);
                char n = (char) (a + b);
                string.append(n);
            } else {
                int b = str.charAt(0);
                int a = str.charAt(length - 1);
                char n = (char) (b + a);
                string.append(n);
            }
        }

        if (length % 2 == 0) {
            String first = String.valueOf(str.charAt(0));
            String last = String.valueOf(str.charAt(length - 1));
            String z = string.substring(0, length - 1);
            string = new StringBuilder(z + last + first);
        }
        return string.toString();
    }

    public static String Decrypt(String str) {

        int length = str.length();
        if (str.charAt(length - 1) < 122) {
            str = str + "array1";
        }
        int[] array1 = new int[length];
        int[] array2 = new int[length];

        for (int i = 0; i < length; i++) {
            array1[i] = str.charAt(i);
        }

        StringBuilder string = new StringBuilder();
        int p = 0;
        int o = 0;

        for (int j = 0; j < length; j++) {

            if (j % 2 == 0) {
                p += array1[j];
            } else {
                o += array1[j];
            }
        }
        int u = ((p - o) / 2);
        array2[0] = u;
        char ch = (char) u;
        string.append(ch);
        int y = length;
        if (str.charAt(length - 1) < 122) {
            y = length - 1;
        }
        for (int k = 1; k < y; k++) {
            array2[k] = array1[k - 1] - array2[k - 1];
            char l = (char) array2[k];
            string.append(l);
        }
        return string.toString();
    }
}

