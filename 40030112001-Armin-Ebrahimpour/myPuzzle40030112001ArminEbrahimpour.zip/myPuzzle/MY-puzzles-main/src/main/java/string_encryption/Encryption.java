package string_encryption;

public class Encryption {
    public static String Encrypt(String str) {
        // we do this with string builder:
        StringBuilder NewStr = new StringBuilder();
        for(int i = 0 ; i < str.length() ; i++){
            int ascii = 0;
            if(i < (str.length() - 1)){
                ascii = str.charAt(i) + str.charAt(i+1);
            }else{
                ascii = str.charAt(0) + str.charAt(str.length()-1);
            }
            NewStr.append((char) ascii);
        }
        if(str.length() % 2 == 0){
            String firstStr = String.valueOf(str.charAt(0));
            String lastStr = String.valueOf(str.charAt(str.length() - 1));
            String substring = NewStr.substring(0, str.length() - 1);
            NewStr = new StringBuilder(substring + lastStr + firstStr);
        }
        return NewStr.toString();
    }

    public static String Decrypt(String str) {
        int len = str.length();
        if (str.charAt(len - 1) < 122) {
            str = str + "a";
        }
        int[] array1 = new int[len];
        int[] array2 = new int[len];

        for (int i = 0; i < len; i++) {
            array1[i] = str.charAt(i);
        }

        StringBuilder NewStr = new StringBuilder();
        int num1 = 0;
        int num2 = 0;

        for (int j = 0; j < len; j++) {

            if (j % 2 == 0) {
                num1 += array1[j];
            } else {
                num2 += array1[j];
            }
        }
        array2[0] = (num1 - num2) / 2;
        char ch = (char) ((num1 - num2) / 2);
        NewStr.append(ch);
        int len1 = len;
        if (str.charAt(len - 1) < 122) {
            len1 = len - 1;
        }
        for (int j = 1; j < len1; j++) {
            array2[j] = array1[j - 1] - array2[j - 1];
            char chr = (char) array2[j];
            NewStr.append(chr);
        }
        return NewStr.toString();
    
}
}
