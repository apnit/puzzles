# puzzles
A mysterious collection of puzzles

Solved by:
1. [40030112086-arman-gholizadeh](https://github.com/apnit/puzzles/pull/3)
2. [40030112006-mohammad-asadpour](https://github.com/apnit/puzzles/pull/4)
3. [40030112104-niousha-maghsoudnia](https://github.com/apnit/puzzles/pull/6)
4. And ... please complete this part I'm busy now

Erfan Zaminpour's Implementation was chosen as one of the best and the cleanest one. So that it's merged with the main branch.
