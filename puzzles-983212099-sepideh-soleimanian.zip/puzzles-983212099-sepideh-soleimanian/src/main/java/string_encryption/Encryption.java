package string_encryption;

public class Encryption {
    public static String Encrypt(String str) {
        StringBuilder strB = new StringBuilder();
        for (int i = 0; i < str.length(); i++){
            if (i == str.length()-1){
                int x = str.charAt(0);
                int y = str.charAt(str.length()-1);
                char z = (char) (x+y);
                strB.append(z);
            }
            else {
                int x = str.charAt(i);
                int y = str.charAt(i+1);
                char z = (char) (x + y);
                strB.append(z);
            }
        }
        String outPut = null;
        if (str.length() % 2 == 0){
            String first = String.valueOf(str.charAt(0));
            String last = String.valueOf(str.charAt(str.length()-1));
            String m = strB.substring(0,str.length()-1);
            strB = new StringBuilder(m + last + first);
        }
        outPut = strB.toString();
        return  outPut;
    }

    public static String Decrypt(String str) {
        StringBuilder strB = new StringBuilder();
        int a = 0;
        for (int i = 0; i < str.length(); i+=2) {
            if (i < str.length()-1){
                int b = str.charAt(i+1);
                int c = str.charAt(i);
                a = a + c - b;

            }
            else{
                int b = str.charAt(i);
                int c = str.charAt(0);
                a = a + b - c;

            }
        }
        char ch = (char) ((a + str.charAt(0))/2);

        for (int i = 0; i < str.length(); i++) {
            if (ch != 0)
            {
                strB.append(ch);
                ch = (char) (str.charAt(i) - ch);
            }
        }
        return strB.toString();
    }
}
