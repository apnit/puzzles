package string_encryption;

public class Encryption {
    public static String Encrypt(String str) {

        int length = str.length();
        String answer = "";

        if (length %2 == 0){

            for (int i = 0; i < length-1; i++) {
                while (i < length - 1) {
                    char word = (char) (str.charAt(i) + str.charAt(i + 1));
                    answer += word;
                    i++;
                }

            }
            answer += str.charAt(length-1);
            answer += str.charAt(0);

            return answer;

        }

        else {

            for (int i = 0; i < length; i++) {
                while (i < length - 1) {
                    char word = (char) (str.charAt(i) + str.charAt(i + 1));
                    answer += word;
                    i++;
                }
                char lastword = (char) (str.charAt(0) + str.charAt(length - 1));
                answer += lastword;
            }

            return answer;
        }

    }

    public static String Decrypt(String str) {

        StringBuilder answer = new StringBuilder();
        int length = str.length();


        int[] a = new int[length];
        int[] b = new int[length];

        for (int i=0;i<length;i++) {
            a[i] = str.charAt(i);
        }

        int zoj = 0;
        int fard = 0;
        for (int i=0;i<length;i++) {

            if (i%2 == 0) {
                zoj += a[i];
            } else {
                fard += a[i];
            }
        }

        int m = ((zoj-fard) / 2);
        b[0] = m;
        char first = (char) m;
        answer.append(first);


        int y = length;
        if (str.charAt(length-1) < 122) {
            y = length - 1;
        }

        for (int i=1;i<y;i++) {
            b[i] = a[i-1]-b[i-1];
            char n = (char) b[i];
            answer.append(n);
        }

        return answer.toString();

    }
}
