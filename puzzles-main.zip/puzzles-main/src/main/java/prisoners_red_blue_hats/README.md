# 100 Prisoners in a Line,Red & Blue Hats and the Executioner

An executioner lines up 100 prisoners single file and puts a red or a blue hat on each prisoner's head. Every prisoner
can see the hats of the people in front of him in the line - but not his own hat, nor those of anyone behind him. The
executioner starts at the end (back) and asks the last prisoner the colour of his hat. He must answer "red" or
"blue." If he answers correctly, he is allowed to live. If he gives the wrong answer, he is killed instantly and
silently. (While everyone hears the answer, no one knows whether an answer was right.) On the night before the line-up,
the prisoners confer on strategy to help them. What should they do?