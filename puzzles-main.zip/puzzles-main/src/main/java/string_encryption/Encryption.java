package string_encryption;

public class Encryption {
    public static String Encrypt(String str) {
        StringBuilder out = new StringBuilder();

        for (int i = 0; i < str.length(); i++){
            if (i == str.length() - 1){
                int x = str.charAt(0);
                int y = str.charAt(str.length() - 1);
                char z = (char) (x + y);
                out.append(z);
            }

            else {
                int x = str.charAt(i);
                int y = str.charAt(i + 1);
                char z = (char) (x + y);
                out.append(z);
            }

        }

        String k;

        if (str.length() % 2 == 0){

            String x1 = String.valueOf(str.charAt(str.length() - 1));
            String x2 = String.valueOf(str.charAt(0));
            String s = out.substring(0, str.length() - 1);
            out = new StringBuilder(s + x1 + x2);

        }
        k = out.toString();
        return  k;
    }

    public static String Decrypt(String str) {
        StringBuilder out = new StringBuilder();
        int s = 0;
        for (int i = 0; i < str.length(); i += 2) {
            if (i == str.length() - 1){
                int x = str.charAt(i);
                int y = str.charAt(0);
                s = s + x - y;
            }
            else{
                int z = str.charAt(i + 1);
                int x = str.charAt(i);
                s = s + x - z;
            }
        }
        char ch = (char) ((s + str.charAt(0)) / 2);

        for (int i = 0; i < str.length(); i++) {
            if (ch != 0)
            {
                out.append(ch);
                ch = (char) (str.charAt(i) - ch);
            }
        }
        return out.toString();
    }
}